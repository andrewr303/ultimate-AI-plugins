# Two Studio plugins — tested local release

The release contains exactly two independent plugins, their editable source, local tools, schemas, examples, demonstrations and validation evidence. The core Linux workflows are tested. The limits below prevent an unrestricted claim of production readiness across every requested source and host.

## Installable packages and source

- [marketing-page-studio.zip](marketing-page-studio.zip) — 9 focused skills and 94 files. [Source and quick start](marketing-page-studio/README.md) · [skill/reference catalog](marketing-page-studio/references/README.md) · [installation](marketing-page-studio/docs/INSTALL.md).
- [product-demo-studio.zip](product-demo-studio.zip) — 10 focused skills and 147 files. [Source and quick start](product-demo-studio/README.md) · [skill/reference catalog](product-demo-studio/references/README.md) · [installation](product-demo-studio/docs/INSTALL.md).
- [Exact package checksums](SHA256SUMS.txt) · [package inventories](packages.json). Each source folder contains `PACKAGE-CONTENTS.json` with per-file hashes. The one-plugin archives include canonical portable and Claude compatibility manifests; no marketplace wrapper is embedded.

Both final ZIPs installed independently in Codex CLI 0.159.2. All 94 marketing files and all 147 video files matched their archives after installation. Read the [host evidence](evidence/host/final-verification-summary.json) before interpreting installation as model-level skill execution.

## Working demonstrations

Open a terminal in this release directory:

```sh
python -m pip install -r marketing-page-studio/requirements.txt
python -m playwright install chromium ffmpeg
python marketing-page-studio/bin/studio.py doctor --launch
python marketing-page-studio/scripts/web.py serve --site demos/website --port 8080
```

Open `http://127.0.0.1:8080`. The complete homepage, feature/workflow page and actual local product are in [demos/website](demos/website/). All names/data are synthetic; processing is deterministic and no message is sent. The separate [site consuming the video package](demos/website-with-video/) uses the same server command with that directory instead. It supports actual video play, pause and seeking.

The video package includes editable source and job files in `product-demo-studio/examples/tandem`. From this release directory:

```sh
python product-demo-studio/bin/studio.py doctor --launch
python product-demo-studio/bin/studio.py render --job product-demo-studio/examples/tandem/promo-vertical.json --output my-preview --preview
```

The primary renderer uses local HTML/Playwright and FFmpeg; FFmpeg/ffprobe must be on PATH. Actual footage uses a separate adapter. Neither plugin requires the other plugin at runtime.

| Output | Composition | Duration | Evidence |
| --- | --- | --- | --- |
| [Vertical promo](demos/video/final-vertical/video.mp4) | 1080 × 1920, 24 fps; intentionally silent | 12 s | [poster](demos/video/final-vertical/poster.png), [captions](demos/video/final-vertical/captions.srt), [QA](demos/video/final-vertical/qa.json) |
| [Landscape promo](demos/video/final-landscape/video.mp4) | 1920 × 1080, 24 fps; original local score | 12 s | [poster](demos/video/final-landscape/poster.png), [captions](demos/video/final-landscape/captions.srt), [QA](demos/video/final-landscape/qa.json) |
| [Actual recorded workflow](demos/video/recorded-workflow/video.mp4) | 1920 × 1080, 24 fps; actual product recording | 11 s | [poster](demos/video/recorded-workflow/poster.png), [QA](demos/video/recorded-workflow/qa.json) |
| Hook previews: [problem](demos/video/hook-problem/video.mp4), [proof](demos/video/hook-proof/video.mp4), [control](demos/video/hook-control/video.mp4) | 540 × 960, 12 fps; explicitly low-cost previews | 12 s each | Per-output receipts, decoded frames and QA |
| [Before/after body preview](demos/video/before-after/video.mp4) | 960 × 540, 12 fps; different product-state emphasis | 12 s | Per-output receipt, decoded frames and QA |

The [campaign manifest](demos/video/experiment-manifest.json) distinguishes previewed combinations from the remaining planned matrix. The [canonical export handoff](demos/video/export-variants.json), [rights/provenance](demos/video/asset-manifest.json), [product evidence](demos/video/product-evidence.json) and [editable project](demos/video/project/) are usable without the development checkout.

## What ran

- [51 clean-package smoke checks](evidence/package-smoke/package-smoke-results.json): actual browser startup, unrelated-working-directory execution, unit and contract suites, schemas/examples, discovery, initialization, resource indexing, campaign generation, two-way handoffs and tamper rejection. Marketing has 44 unit tests; video has 69. Each independently bundled contract suite has 30 tests; these counts include shared code tested in each package.
- [134 website browser checks](evidence/website/browser-qa.json) at 390, 768, 1024 and 1440 pixels. Covered real states, cancel/reset/retry/replay, forward/reverse scroll, keyboard/focus, reduced motion, resource/console errors, layout and screenshots. The inactive story body contrast was measured and repaired to 5.49:1.
- [Website screenshots](evidence/website/contact-sheet.jpg), including meaningful result/error/workflow states; [independent visual observations](evidence/independent-visual-review.json).
- [Actual capture handoff](evidence/interop/capture-to-video/handoff-receipt.json) and [video-to-site browser check](evidence/interop/video-to-website-browser-qa.json): native controls, H.264 decode, play/pause/seek to 8 seconds, no console errors or horizontal overflow at all four widths. HTTP byte-range serving was fixed and tested.
- Seven encoded videos passed dimensions, duration, frame rate/count, full decode, black-frame intervals and requested-audio checks. Landscape measured −16.00 LUFS and −4.22 dBTP. [Render-source receipts](evidence/render-receipts-verified.json) match the actual packaged code, configuration, assets and output bytes.
- An additional one-second primary render from the independently unpacked video archive passed QA and receipt validation. This proves packaged execution; it is distinct from the full demonstration renders.

Technical checks, sampled-frame visual/editorial review and actual browser playback are separate evidence. No automated pass is represented as proof of persuasive design or campaign performance.

## Source integration and contracts

[Source integration and attribution map](marketing-page-studio/docs/source-audit/source-integration.md) · [file/archive inventory](marketing-page-studio/docs/source-audit/inventory.json) · [third-party notices](marketing-page-studio/THIRD_PARTY_NOTICES.md). Current and legacy Launch Motion, Scrollcraft, Product Demo Director and Agentic Product Demo were inspected. Missing upstream commands were replaced with working local tools. Unlicensed standalone prose/code and excluded upstream films/assets were not copied.

[Shared contract documentation](marketing-page-studio/contracts/README.md) covers brand, evidence, capture, interactive states, campaign, storyboard, rendering, exports, QA, rights and experiments. Each plugin bundles the same required resources independently. The skills are concise routers; recipes, renderer guidance, profiles and examples load on demand.

## Material limits

1. **Two sources remain inaccessible.** Video Shotcraft and Brag exceed the attachment transfer tool’s 32 MiB limit. Neither archive’s payload, license, full/slim workflow or recipes were inspected or copied. Their integration cannot be claimed; independent local recipes fill the available workflows. Public repository URLs or smaller source payloads are needed to finish that source-specific work.
2. **Host execution has limits.** Claude Code is absent. Codex CLI installation is verified, but model-level skill routing was blocked by HTTP 401 in isolated authentication-free attempts. The final rebuilt marketing artifact was not retried for routing. Codex desktop, Windows/macOS, React/Next application integration and complete optional Remotion/HyperFrames renders were not executed. Platform-specific specifications are separately marked verified or unverified in the editable profiles.
3. **Creative review has a stated scope.** Actual decoded frames and contact sheets were inspected; complete normal-speed listening and narration-to-picture alignment were not tested. No spoken narration was requested for these examples. The actual recorded interface is small at embedded/social widths and serves documentary workflow proof; the controlled compositions provide larger promotional detail. A full screen-reader/WCAG certification was not performed.
4. **Chat download delivery is blocked.** The cloud execution user cannot create the configured `/codex/.../output` folder (`Permission denied`). These are real staged files under `/workspace/work/release-candidate`; no download links to nonexistent files are supplied. The complete `studio-release.zip` is a handoff bundle containing the two installable ZIPs, source, demos and evidence, not a third plugin.

No deployment, external upload, paid generation or user-global plugin installation was performed. No private repository/capture data was sent to a third-party provider.
