#!/usr/bin/env python3
"""Materialize a canonical experiment manifest into independent render-job projects. No invented hooks."""
import argparse,copy,importlib.util,json,re,shutil,sys
from pathlib import Path
from render import resolve
RATIOS={'9:16':(1080,1920),'16:9':(1920,1080),'1:1':(1080,1080),'4:5':(1080,1350)}

def materialize(job,base,manifest,out,limit=None,use="ads"):
 out=Path(out)
 if limit is not None and limit<1:raise ValueError('limit must be positive')
 validator=Path(__file__).resolve().parents[1]/'contracts'/'validate.py'
 if not validator.is_file():raise ValueError('Bundled contracts validator missing; reinstall the plugin')
 spec=importlib.util.spec_from_file_location('variant_contracts',validator);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 for schema,data in [('render-job',job),('experiment-manifest',manifest)]:
  report=mod.validate(schema,data)
  if not report['ok']:raise ValueError('Invalid '+schema+': '+json.dumps(report['errors']))
 ids=[x['id'] for x in manifest['experiments']]
 if len(ids)!=len(set(ids)):raise ValueError('Duplicate experiment IDs')
 if any(not re.fullmatch('[a-z][a-z0-9._-]*',x) for x in ids):raise ValueError('Experiment IDs must be safe portable identifiers')
 hooks={x['id']:x for x in manifest['hooks']};bodies={x['id']:x for x in manifest['bodies']};rows=[]
 if manifest['productRevision']!=job['productRevision']:raise ValueError('Experiment and render job revisions differ')
 for e in manifest['experiments']:
  if e['hookId'] not in hooks or e['bodyId'] not in bodies:raise ValueError('Unknown hook or body ID')
 evidence=json.loads(resolve(base,job['evidence']).read_text()) if job.get('evidence') else None
 prepared=[]
 for e in manifest['experiments'][:limit]:
  if e['aspectRatio'] not in RATIOS:raise ValueError('Unsupported authored aspect ratio: '+e['aspectRatio'])
  v=copy.deepcopy(job);body=bodies[e['bodyId']];v.update(id=e['id'],hook=hooks[e['hookId']]['text'],promise=body['proof'],body='before-after' if 'before' in body['approach'].lower() or 'before' in e['bodyId'] else ('review' if any(word in body['approach'].lower() for word in ['review','edit','human']) else 'context'),placement=e['placement'],width=RATIOS[e['aspectRatio']][0],height=RATIOS[e['aspectRatio']][1],duration=e['duration'],cta=e['cta'],claimIds=body['claims'],campaignId=manifest['campaignId'])
  # Caption timestamps scale with the selected duration, retaining complete thoughts.
  factor=v['duration']/job['duration']
  for c in v.get('captions',[]):c['start']=round(c['start']*factor,4);c['end']=round(c['end']*factor,4)
  report=mod.validate('render-job',v,project_root=Path(base),evidence=evidence,use=use,check_files=True)
  if not report['ok']:raise ValueError('Variant contract invalid: '+json.dumps(report['errors']))
  prepared.append(v)
 out.mkdir(parents=True,exist_ok=True)
 for v in prepared:
  paths=[v.get('evidence'),v.get('template'),v.get('font'),v.get('source',{}).get('path')]+[a['path'] for a in v.get('audio',[])]+list(v.get('sourceHashes',{}))
  if (Path(base)/'asset-manifest.json').is_file():
   rights=json.loads((Path(base)/'asset-manifest.json').read_text());paths+=['asset-manifest.json']+[a['path'] for a in rights['assets']]+[a['source']['path'] for a in rights['assets'] if a.get('source',{}).get('path')]
  for rel in set(filter(None,paths)):
   src=resolve(base,rel);dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
   if src.resolve()!=dest.resolve():shutil.copy2(src,dest)
  dest=out/(v['id']+'.json');dest.write_text(json.dumps(v,indent=2)+'\n');rows.append({'id':v['id'],'job':dest.name,'status':'planned'})
 result=copy.deepcopy(manifest)
 for e in result['experiments']:e['status']='planned'
 (out/'experiment-manifest.json').write_text(json.dumps(result,indent=2)+'\n');(out/'render-jobs.json').write_text(json.dumps(rows,indent=2)+'\n');return rows
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--job',required=True);p.add_argument('--manifest',required=True);p.add_argument('--output',required=True);p.add_argument('--limit',type=int);p.add_argument('--use',choices=['video','ads'],default='ads');a=p.parse_args()
 try:
  jp=Path(a.job).resolve();rows=materialize(json.loads(jp.read_text()),jp.parent,json.loads(Path(a.manifest).read_text()),a.output,a.limit,a.use);print(json.dumps({'jobs':len(rows),'output':a.output}))
 except (ValueError,KeyError,FileNotFoundError) as e:print(json.dumps({'status':'failed','error':str(e)}),file=sys.stderr);sys.exit(2)
