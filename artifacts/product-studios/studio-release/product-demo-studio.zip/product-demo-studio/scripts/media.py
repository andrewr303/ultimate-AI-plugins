#!/usr/bin/env python3
"""Inspect the delivered encoding and create decoded-frame review artifacts. No taste score."""
from __future__ import annotations
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path

def run(args,check=True):
 p=subprocess.run([str(a) for a in args],capture_output=True,text=True)
 if check and p.returncode: raise RuntimeError(f'{args[0]} failed ({p.returncode}): {p.stderr[-2000:]}')
 return p

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def probe(path):
 return json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',path]).stdout)

def fraction(v):
 a,b=v.split('/') if '/' in v else (v,'1');return float(a)/float(b) if float(b) else 0

def inspect(path,expected=None,review_dir=None):
 path=Path(path);p=probe(path);v=next((s for s in p['streams'] if s['codec_type']=='video'),None)
 if not v:raise ValueError('No video stream')
 a=next((s for s in p['streams'] if s['codec_type']=='audio'),None);checks=[]
 def check(name,ok,detail):checks.append({'name':name,'status':'passed' if ok else 'failed','detail':detail})
 duration=float(p['format']['duration']);fps=fraction(v['avg_frame_rate']);frames=int(v.get('nb_read_frames',v.get('nb_frames','0')))
 check('video-stream',v['codec_name']=='h264' and v.get('pix_fmt')=='yuv420p',{'codec':v['codec_name'],'pixelFormat':v.get('pix_fmt')})
 args=['ffmpeg','-hide_banner','-nostats','-v','info','-xerror','-i',path,'-map','0:v:0','-vf','blackdetect=d=0.15:pic_th=0.98:pix_th=0.05']
 if a:args+=['-map','0:a:0','-af','ebur128=peak=true']
 decoded=run(args+['-f','null','-'],check=False);black=[{'start':float(m[0]),'end':float(m[1]),'duration':float(m[2])} for m in re.findall(r'black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)',decoded.stderr)]
 check('full-decode',decoded.returncode==0,decoded.stderr[-1200:] if decoded.returncode else {'decodedFrames':frames})
 check('black-intervals',not black,black)
 if expected:
  check('dimensions',(v['width'],v['height'])==(expected['width'],expected['height']),{'actual':[v['width'],v['height']],'expected':[expected['width'],expected['height']]})
  check('frame-rate',abs(fps-expected['fps'])<.001,{'actual':fps,'expected':expected['fps']})
  check('duration',abs(duration-expected['duration'])<=1/expected['fps']+.025,{'actual':duration,'expected':expected['duration']})
  check('frame-count',frames==round(expected['duration']*expected['fps']),{'actual':frames,'expected':round(expected['duration']*expected['fps'])})
  check('audio-presence',bool(a)==(bool(expected.get('audio')) or expected.get('source',{}).get('audioPolicy')=='preserve'),{'present':bool(a),'requested':bool(expected.get('audio'))})
 audio={'status':'not-requested','reason':'Intentional sound-off creative; no audio stream was requested.'}
 if a:
  loud=run(['ffmpeg','-hide_banner','-nostats','-i',path,'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-f','null','-']).stderr
  m=re.search(r'\{\s*"input_i".*?\}',loud,re.S);measured=json.loads(m.group(0)) if m else {}
  audio={'status':'measured','integratedLufs':measured.get('input_i'),'truePeakDbtp':measured.get('input_tp'),'targetLufs':-16,'maxTruePeakDbtp':-1.0}
  check('audio-true-peak',float(measured.get('input_tp','inf'))<=-1.0,audio)
  check('audio-loudness',abs(float(measured.get('input_i','inf'))+16)<=1.5,audio)
 review=[]
 if review_dir:
  from PIL import Image,ImageDraw
  rd=Path(review_dir);rd.mkdir(parents=True,exist_ok=True);times=sorted(set(round(min(duration-1/fps,max(0,t)),3) for t in [0,1,2.8,4.1,4.5,6,8.7,10,duration-1/fps]))
  tiles=[]
  for n,t in enumerate(times):
   target=rd/f'frame-{n:02d}-{t:06.2f}.png';run(['ffmpeg','-v','error','-i',path,'-vf',f'select=eq(n\\,{min(frames-1,round(t*fps))})','-fps_mode','vfr','-frames:v','1','-c:v','png','-pix_fmt','rgb24','-threads','1','-y',target]);im=Image.open(target).convert('RGB');im.thumbnail((440,360));tile=Image.new('RGB',(460,398),'#f4f1e9');tile.paste(im,((460-im.width)//2,15));ImageDraw.Draw(tile).text((14,377),f'{t:.2f}s | decoded final MP4',fill='#18251f');tiles.append(tile);review.append({'time':t,'path':target.name,'sha256':digest(target)})
  sheet=Image.new('RGB',(460*3,398*((len(tiles)+2)//3)),'#e8e8df')
  for n,tile in enumerate(tiles):sheet.paste(tile,((n%3)*460,(n//3)*398))
  sheet.save(rd/'contact-sheet.jpg',quality=91)
 return {'schemaVersion':'1.0.0','artifact':path.name,'sha256':digest(path),'dimensions':[v['width'],v['height']],'fps':fps,'duration':duration,'frames':frames,'audio':audio,'checks':checks,'status':'passed' if all(c['status']=='passed' for c in checks) else 'failed','visualReview':{'status':'required','reason':'Open decoded contact-sheet and inspect playback; mechanical checks do not judge persuasion or readable typography.'},'reviewFrames':review}

def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True);q=sub.add_parser('inspect');q.add_argument('file');q.add_argument('--output');q.add_argument('--review-dir');q.add_argument('--job');a=p.parse_args();expected=json.loads(Path(a.job).read_text()) if a.job else None;result=inspect(a.file,expected,a.review_dir);text=json.dumps(result,indent=2)
 if a.output:Path(a.output).parent.mkdir(parents=True,exist_ok=True);Path(a.output).write_text(text+'\n')
 print(text);return 0 if result['status']=='passed' else 1
if __name__=='__main__':
 try:sys.exit(main())
 except (ValueError,RuntimeError,FileNotFoundError) as exc:print(json.dumps({'status':'failed','error':str(exc)}),file=sys.stderr);sys.exit(2)
