---
name: pds-render
description: "Use when selecting an explicit product-video renderer, producing previews/final exports, compositing real footage, or reproducing a render with source and configuration hashes."
---

# Rendering and adapters

Read [renderer](../../references/renderer.md), [execution](../../references/execution.md) and the render-job contract. Run the doctor.

1. Validate job, assets, revision, storyboard timing, output geometry/fps/duration and hashes. Fail usefully for absent files or unsupported options.
2. Select an explicit supported adapter. `html-playwright` is primary; `footage` preserves recorded sources. Remotion needs its local installed CLI; Hyperframes uses caller-verified argv and is not a presumed installed capability.
3. Run `python bin/studio.py render --job JOB.json --output OUTPUT --preview` and inspect frames/movement before final encoding.
4. Render selected finals with `python bin/studio.py render --job JOB.json --output OUTPUT`. Keep variants/hash identities distinct; cache only matching inputs.
5. Inspect with `python bin/studio.py media inspect VIDEO.mp4 --output REPORT.json` and complete encoded-media review.
6. Retain artifact hash, renderer/version, input snapshot, dimensions, fps, duration, posters/captions and QA. Reject stale evidence after changes.

Report missing dependencies and documented remedies; never silently switch engines, remove narration or change ratio. Respect separate renderer terms.
