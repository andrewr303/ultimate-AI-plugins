# Encoded-media QA and editorial repair

Bind review to the exact delivered hash and current source/configuration. A changed render invalidates previous QA. Run `python bin/studio.py media inspect VIDEO.mp4 --output REPORT.json` for implemented inspection; consult renderer guidance for supported checks. Do not mark unimplemented checks passed.

| Area | Evidence |
| --- | --- |
| Geometry | Encoded dimensions, ratio and pixel format |
| Time | fps, duration, frame count and expected tolerance |
| Decode | Full FFmpeg decode and errors |
| Picture | Black/blank scan plus inspected relevant frames |
| Product | Native sharpness, complete UI units, qualifiers |
| Captions | Timing, longest lines, safe areas, rendered bounds |
| Cursor | Target alignment, press hold, no clipping |
| Sources | Hashes, revision, native density under maximum crop |
| Audio | Requested stream, duration, peaks/clipping, loudness target |
| Sync | Spoken phrase/cue and corresponding action |

Interpret scans: a deliberate dark opening can be valid; bright emptiness evades black detection. Frame-difference spikes may be intentional cuts. Findings require inspection, not automatic taste judgments.

Extract opening, action, processing/result, transition boundaries, caption-heavy state, CTA and ending from the actual encoded file. Inspect native pixels and target size including 320/390px. Sharp dashboards can still be too small. Recompose complete units instead of severing fragments. Check cursor in transformed output.

Watch normal-speed motion when available: causality, settled reading, camera arrival, continuity, captions and CTA. Repeat loop boundaries. Stills cannot prove pacing, shimmer or velocity. Listen when available; separate that from audio measurements.

Editorial questions: does the intended viewer understand product/action/benefit/next step? Does visible proof support the promise? Does the opening give a reason to watch? Is the story understandable muted? Can sample states be mistaken for customer activity?

Record concrete defects by time/frame, evidence, consequence and repair. Missing proof needs capture or a narrower claim; unreadable UI needs recomposition; rushed results need time; bad cursor targeting needs coordinate correction. Render selective previews and rerun affected checks. Preserve useful comparisons. Keep technical, editorial and intended-host routing status distinct; encoder/model success cannot prove persuasion or campaign performance.
