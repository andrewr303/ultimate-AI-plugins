"""TinyRoute documentation trial fixture."""
