#!/usr/bin/env python3
"""Optional, local prose review aid; Python standard library only.

Usage: python scripts/lint.py [draft.txt | -] --genre email --tone warm
Reads UTF-8 from a file or stdin. Never writes files, sends data, rewrites prose,
scores writing, or predicts authorship. A match is a REVIEW candidate, not an
error: context, evidence and intentional repetition can justify every example.
The small English phrase checks have limited coverage; silence proves nothing.

Code, quotations, blockquotes, URLs, email addresses and path tokens are protected.
--include-quotes includes prose quotations/blockquotes, while code and technical
tokens remain protected. Positions are zero-based Unicode character offsets,
with exclusive end offsets; lines/columns are one-based. CRLF is preserved.
Genre and free-text tone are reported as context, never scored.
--straight-quotes and --no-em-dash opt into literal typography conventions.
Exit: 0 completed; 1 only when --strict finds a selected convention; 2 error.
"""

import argparse
from bisect import bisect_right
from dataclasses import asdict, dataclass
import json
import re
import sys

GENRES = ("generic", "email", "message", "post", "essay", "docs", "marketing", "fiction")
REVIEW = "REVIEW"


@dataclass(frozen=True)
class Finding:
    severity: str
    rule_id: str
    message: str
    line: int
    column: int
    offset_start: int
    offset_end: int
    snippet: str
    convention: bool = False


def _mask(value):
    # A sentinel prevents a regex from joining prose across an excluded span.
    return "".join(ch if ch in "\r\n" else "\0" for ch in value)


def mask_sources(text, include_quotes=False):
    """Return an equal-length scan surface; never alter the original text."""
    lines, fence = [], None
    prefix = r"^(?: {0,3}>[ \t]?)* {0,3}"
    for line in text.splitlines(keepends=True):
        marker = re.match(prefix + r"(`{3,}|~{3,})(.*)", line)
        if fence:
            lines.append(_mask(line))
            if re.match(prefix + re.escape(fence[0]) + "{" + str(len(fence)) + r",}[ \t]*\r?\n?$", line):
                fence = None
        elif marker:
            fence = marker.group(1)
            lines.append(_mask(line))
        else:
            lines.append(line)
    scan = "".join(lines)
    scan = re.sub(r"(?<!`)(`+)(?!`)[\s\S]*?(?<!`)\1(?!`)", lambda m: _mask(m[0]), scan)
    if not include_quotes:
        # Include Markdown lazy continuation lines until an empty line.
        in_block = False
        lines = []
        for line in scan.splitlines(keepends=True):
            if not line.strip():
                in_block = False
            elif re.match(r"^ {0,3}>", line):
                in_block = True
            lines.append(_mask(line) if in_block else line)
        scan = "".join(lines)
        for pattern in (
            r'"(?:[^"\\]|\\.)*"', r"“[^”]*”", r"«[^»]*»", r"‹[^›]*›",
            r"「[^」]*」", r"『[^』]*』", r"„[^“”]*[“”]",
            r"(?<!\w)'(?:[^'\n]|(?<=\w)'(?=\w))*'(?!\w)",
            r"(?<!\w)‘(?:[^’]|(?<=\w)’(?=\w))*’(?!\w)",
        ):
            scan = re.sub(pattern, lambda m: _mask(m[0]), scan)
    # Keep trailing sentence punctuation available for boundary checks.
    def token(match):
        raw = match[0]
        body = raw.rstrip(".,;:!?)]}")
        return _mask(body) + raw[len(body):]

    for pattern in (
        r"\b(?:https?://|www\.)[^\s<>\"']+",
        r"\b[\w.!#$%&'*+/=?^`{|}~-]+@[\w.-]+\.[\w-]+\b",
        r"(?<!\w)(?:[A-Za-z]:[\\/]|\\\\|\.{0,2}/|~/|[\w.-]+[/\\])[^\s<>\"']+",
    ):
        scan = re.sub(pattern, token, scan)
    return scan


# These are narrow constructions, not a vocabulary blacklist. A match cannot
# determine whether a claim is supported or whether an author intended a device.
PHRASES = (
    ("stock-opening", r"\bI hope this (?:email|message) finds you well\b",
     "Consider opening with the purpose or news if this greeting adds little for the reader."),
    ("stock-opening", r"\bIn (?:today['’]s (?:fast[- ]paced |ever[- ]changing )?world|a world where)\b",
     "Check whether this broad opening can begin with the specific subject instead."),
    ("staged-insight", r"\b(?:Here['’]s what (?:most people miss|nobody tells you)|The uncomfortable truth is|What if I told you)\b",
     "Check whether the promised revelation earns this setup; the point may stand on its own."),
    ("claim-scope", r"\b(?:the world['’]s (?:best|leading|only)|100% (?:safe|effective|accurate|guaranteed)|guaranteed to (?:work|succeed)|this changes everything)\b",
     "Verify the evidence and scope of this claim; this scan cannot judge its support."),
)


def check(text, *, genre="generic", tone="", include_quotes=False,
          straight_quotes=False, no_em_dash=False):
    """Return advisory findings only. Genre/tone do not change thresholds."""
    if genre not in GENRES:
        raise ValueError("unknown genre: " + genre)
    scan = mask_sources(text, include_quotes)
    findings = []
    line_starts = [0] + [match.end() for match in re.finditer(r"\r\n|[\r\n]", text)]

    def add(start, end, rule_id, message, convention=False):
        if "\0" in scan[start:end]:
            return
        line = bisect_right(line_starts, start)
        findings.append(Finding(REVIEW, rule_id, message, line,
                                start - line_starts[line - 1] + 1,
                                start, end, text[start:end], convention))

    for rule_id, pattern, message in PHRASES:
        for match in re.finditer(pattern, scan, re.I):
            add(match.start(), match.end(), rule_id, message)

    closer = re.search(r"\b(?:Only time will tell|The possibilities are endless|This is just the beginning)[.!]?\s*\Z", scan, re.I)
    if closer:
        end = closer.start() + len(closer[0].rstrip())
        add(closer.start(), end, "stock-closer",
            "Check whether this final sentence gives the reader a useful ending.")

    framing = r"\b(?:It(?: is|['’]s) important to note that|The key takeaway is|What this means is)\b"
    seen = set()
    for match in re.finditer(framing, scan, re.I):
        # Only sentence/paragraph openings; one occurrence alone is not a finding.
        before = scan[:match.start()]
        if before.strip() and before.rstrip()[-1] not in ".!?" and before.rsplit("\n", 1)[-1].strip():
            continue
        key = re.sub(r"\s+", " ", match[0].casefold())
        if key in seen:
            add(match.start(), match.end(), "repeated-framing",
                "This sentence opening repeats; check whether the framing is doing useful work.")
        seen.add(key)

    previous = None
    # Deliberately conservative sentence approximation; no cadence measurements.
    for match in re.finditer(r"[^.!?\n]+(?:[.!?]+(?=\s|$)|(?=\n|$))", scan):
        body = match[0].strip()
        if "\0" in body or not body:
            previous = None
            continue
        key = re.sub(r"\s+", " ", body.casefold())
        start = match.start() + len(match[0]) - len(match[0].lstrip())
        if len(re.findall(r"\b\w+\b", body)) >= 4 and key == previous:
            add(start, start + len(body), "adjacent-duplicate",
                "This sentence repeats the preceding sentence; check whether that is intentional.")
        previous = key

    for enabled, pattern, rule_id, message in (
        (straight_quotes, r"[‘’“”]", "straight-quotes", "Selected convention: use straight quotation marks/apostrophes in authored prose."),
        (no_em_dash, "—", "no-em-dash", "Selected convention: avoid em dashes in authored prose."),
    ):
        if enabled:
            for match in re.finditer(pattern, scan):
                add(match.start(), match.end(), rule_id, message, True)
    return sorted(findings, key=lambda finding: (finding.offset_start, finding.rule_id))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("path", nargs="?", help="UTF-8 file; default or '-' reads stdin")
    parser.add_argument("--genre", choices=GENRES, default="generic", help="reader-supplied context")
    parser.add_argument("--tone", default="", help="free-text context; never scored")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--json", action="store_true", help="emit structured findings and context")
    mode.add_argument("--detect", action="store_true", help="alias for the default advisory text report; no authorship detection")
    parser.add_argument("--include-quotes", action="store_true", help="also review prose quotations and blockquotes")
    parser.add_argument("--straight-quotes", action="store_true", help="select a straight-quotes convention")
    parser.add_argument("--no-em-dash", action="store_true", help="select a no-em-dash convention")
    parser.add_argument("--strict", action="store_true", help="exit 1 only for findings under a selected convention")
    args = parser.parse_args(argv)
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    try:
        if args.path and args.path != "-":
            with open(args.path, encoding="utf-8", newline="") as source:
                text = source.read()
        else:
            text = sys.stdin.buffer.read().decode("utf-8")
    except (OSError, UnicodeError) as exc:
        parser.exit(2, "lint.py: unable to read UTF-8 input: " + str(exc) + "\n")
    findings = check(text, genre=args.genre, tone=args.tone,
                     include_quotes=args.include_quotes,
                     straight_quotes=args.straight_quotes, no_em_dash=args.no_em_dash)
    context = {"genre": args.genre, "tone": args.tone,
               "include_quotes": args.include_quotes,
               "conventions": [name for name, selected in
                               (("straight-quotes", args.straight_quotes), ("no-em-dash", args.no_em_dash)) if selected]}
    if args.json:
        print(json.dumps({"schema_version": 1, "context": context,
                          "findings": [asdict(f) for f in findings]}, ensure_ascii=False, indent=2))
    else:
        print("Advisory review; genre=" + args.genre + "; tone=" + (args.tone or "unspecified"))
        for finding in findings:
            print(f"REVIEW {finding.line}:{finding.column} [{finding.rule_id}] {finding.snippet!r}: {finding.message}")
        if not findings:
            print("No candidates matched these limited checks.")
    return int(args.strict and any(f.convention for f in findings))


if __name__ == "__main__":
    sys.exit(main())
