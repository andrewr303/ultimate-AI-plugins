# Source and provenance notice

This revision adapts the user-supplied Ultimate Prose 4.2.0 skill. Its frontmatter declares `license: MIT`; the supplied archives do not contain a separate license text or copyright notice. That original metadata declaration is recorded here without inventing an author or representing an independent rights clearance. The supplied author's personal profile and private-source identifiers are excluded.

The v5 tone guide, calibration guidance, scanner implementation, and fixtures were written for this revision. Public repositories informed abstract design choices only; no third-party implementation, profile, corpus, or style-entry text is bundled. See `references/research.md` for source links and freshness limits. No dependency on those repositories is required.

Prepared for the requested personal-use adaptation. No new copyright owner is inferred from the supplied files.
