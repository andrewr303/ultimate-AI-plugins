"""Boundary and CLI tests for the optional advisory scanner."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "lint.py"
sys.path.insert(0, str(SCRIPT.parent))
import lint


class ScannerTests(unittest.TestCase):
    def run_cli(self, *args, data=b""):
        return subprocess.run([sys.executable, str(SCRIPT), *args], input=data,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def test_protected_sources_and_exact_unicode_positions(self):
        text = ('> This changes everything.\r\nLazy quotation continuation.\r\n\r\n'
                '```txt\r\nThis changes everything.\r\n```\r\n'
                '`This changes everything` “This changes everything.”\r\n'
                '«This changes everything.» 「This changes everything.」\r\n'
                'Café 🐈: This changes everything.\r\n')
        masked = lint.mask_sources(text)
        self.assertEqual(len(masked), len(text))
        self.assertEqual([(i, c) for i, c in enumerate(masked) if c in "\r\n"],
                         [(i, c) for i, c in enumerate(text) if c in "\r\n"])
        findings = lint.check(text)
        self.assertEqual(len(findings), 1)
        finding = findings[0]
        self.assertEqual(finding.offset_start, text.rindex("This changes everything"))
        self.assertEqual(finding.line, 9)
        self.assertEqual(finding.column, 9)
        self.assertEqual(text[finding.offset_start:finding.offset_end], finding.snippet)
        self.assertEqual(lint.check("First line.\rThis changes everything.")[0].line, 2)

    def test_include_quotes_keeps_code_and_technical_tokens_protected(self):
        text = ('"This changes everything."\n> This changes everything.\n\n'
                '`This changes everything`\n> ```txt\n> This changes everything.\n> ```\n'
                'https://example.test/“world” a.b@example.test /srv/“data” ./“data” C:\\“data”\\file\n')
        findings = lint.check(text, include_quotes=True, straight_quotes=True)
        self.assertEqual([f.rule_id for f in findings], ["claim-scope", "claim-scope"])

    def test_single_quotes_contractions_and_unclosed_fences(self):
        text = "'This changes everything.' ‘This changes everything.’ It's a draft.\n"
        self.assertFalse(lint.check(text))
        self.assertEqual(len(lint.check(text, include_quotes=True)), 2)
        for fence in ("```", "~~~~"):
            self.assertFalse(lint.check(fence + "\nThis changes everything.\n"))

    def test_masks_cannot_join_a_signal_or_duplicate(self):
        text = 'This changes `source` everything.\nThis changes "source" everything.\n'
        self.assertFalse(lint.check(text))
        self.assertFalse(lint.check('The draft is ready today. "Quoted source." The draft is ready today.'))

    def test_small_contextual_signals_are_advisory(self):
        text = ("In today's world, we need a plan. The uncomfortable truth is we need more time. "
                "The world's best system is guaranteed to work. Only time will tell.")
        findings = lint.check(text)
        self.assertEqual(len(findings), 5)
        self.assertTrue(all(f.severity == "REVIEW" and not f.convention for f in findings))
        self.assertIn("cannot judge", findings[2].message)

    def test_no_vocabulary_typography_or_cultural_defaults(self):
        text = ("Robust standard errors matter. Leverage rose. Moreover, it’s a useful framework — "
                "a critical one. Fuck, that was hard. Hello, dear friend.\n"
                "The question remains open. Can you meet? Approved. Ship it.")
        self.assertFalse(lint.check(text, genre="email", tone="warm, bold, playful"))
        self.assertFalse(lint.check("The sun rises. The sun rises."))  # short repetition can be deliberate

    def test_repeated_framing_and_adjacent_duplicate(self):
        text = ("The key takeaway is timing. The key takeaway is staffing.\n"
                "The report will arrive tomorrow. The report will arrive tomorrow.")
        findings = lint.check(text)
        self.assertEqual([f.rule_id for f in findings], ["repeated-framing", "adjacent-duplicate"])
        self.assertEqual(findings[1].snippet, "The report will arrive tomorrow.")
        self.assertFalse(lint.check("The key takeaway is timing."))

    def test_strict_only_applies_to_selected_conventions(self):
        text = "This changes everything. It’s ready — send it."
        normal = self.run_cli("--strict", data=text.encode())
        self.assertEqual(normal.returncode, 0)
        for option in ("--straight-quotes", "--no-em-dash"):
            selected = self.run_cli(option, "--strict", "--json", data=text.encode())
            self.assertEqual(selected.returncode, 1)
            findings = json.loads(selected.stdout)["findings"]
            self.assertTrue(all(f["severity"] == "REVIEW" for f in findings))
            self.assertTrue(any(f["convention"] for f in findings))
            self.assertEqual(self.run_cli(option, data=text.encode()).returncode, 0)

    def test_json_context_and_file_are_preserved(self):
        data = "Café 🐈\r\nThis changes everything.\r\n".encode()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "draft.txt"
            path.write_bytes(data)
            result = self.run_cli(str(path), "--json", "--genre", "fiction", "--tone", "dry and lyrical")
            self.assertEqual(path.read_bytes(), data)
        self.assertEqual(result.returncode, 0)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["context"]["tone"], "dry and lyrical")
        self.assertEqual(payload["context"]["genre"], "fiction")
        self.assertEqual(payload["findings"][0]["offset_start"], data.decode().index("This"))
        self.assertEqual(set(payload), {"schema_version", "context", "findings"})

    def test_cli_help_errors_and_empty_input(self):
        self.assertEqual(self.run_cli("--help").returncode, 0)
        self.assertEqual(self.run_cli("-").returncode, 0)
        plain, detect = self.run_cli(), self.run_cli("--detect")
        self.assertEqual(plain.stdout, detect.stdout)
        for args, data in ((["--genre", "unknown"], b""), (["--json", "--detect"], b""),
                           (["/missing/file.txt"], b""), ([], b"\xff")):
            result = self.run_cli(*args, data=data)
            self.assertEqual(result.returncode, 2)
            self.assertNotIn(b"Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
