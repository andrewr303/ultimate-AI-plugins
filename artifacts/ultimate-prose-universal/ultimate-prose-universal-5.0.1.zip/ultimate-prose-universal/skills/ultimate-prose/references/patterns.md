# Contextual editing patterns

These are reasons to inspect a passage, not universal bans or signs that establish who wrote it. Find the reader's problem and repair that problem. A phrase's mere presence does not justify an edit. All examples here are synthetic.

| Pattern | Reader problem | Useful move | Legitimate counterexample |
|---|---|---|---|
| Generic opening: "In today's fast-paced world…" | Delays this piece's subject | Start with the actual observation, question, scene, or action | Brief orientation for an unfamiliar reader; an intentional parody |
| Inflated significance: "a revolutionary leap" | Promises more than the material establishes | Explain the supported change or remove the claim | An owned opinion, supported historic description, or quoted claim |
| Decorative contrast: "Not just a tool. A movement." | Adds drama without a useful distinction | Name what changes in practice | "The limit applies per account, not per person" corrects real scope |
| Staged insight: "Here's what nobody tells you" | Performs a reveal without earning it | State the actual point and evidence | A character's dialogue, a deliberately comic setup, or an actual question |
| Repeated significance: "This matters. It's the key. That changes everything." | Repeats one proposition | Keep the sentence that contributes a concrete implication | Separate consequences, deliberate anaphora, or a necessary reminder |
| Synonym cycling: product/platform/ecosystem/solution | Makes one referent look like several objects | Repeat the accurate noun | Distinct entities that really require different terms |
| Fake specificity: "I learned this last Tuesday" | Invents credibility | Restore the supplied facts or use a marked placeholder | A supplied event or clearly framed fiction |
| Mechanical paragraph shape | Makes every thought sound prepackaged | Follow this argument's development | Steps, parallel comparisons, checklists, or a chosen poetic pattern |
| Forced empathy: "I know exactly how you feel" | Claims an experience or knowledge the speaker may not have | Acknowledge the stated situation and respond concretely | A supplied shared experience; the user's deliberate wording |
| Empty closer: "The future belongs to those who act" | Repeats significance and delays the ending | Stop, or use the actual next step or implication | A requested rallying speech or a fitting artistic ending |
| Overpolished neutrality | Removes a real preference, feeling, or boundary | Preserve the user's position and honest texture | Deliberate neutral reporting or diplomatic phrasing that keeps the decision |

## Meaning comes before replacements

"The trial suggests a possible improvement" must not become "The trial proves it works." Preserve qualifiers, sample limits, time windows, attribution, units, and conditions. A stronger verb is useful only when it is equally true. Never turn an association into a cause just to join two short sentences.

"I can't make Friday" must remain a refusal when made warmer. "The target is June, if testing passes" remains a target with a dependency when made bolder. "The preview loads; export fails" does not prove why the export fails. Smoother phrasing cannot supply the missing evidence.

An example, an image, or a precise mechanism can enliven prose when the brief supports it. If facts are sparse, write a proportionately sparse piece. Do not make up numbers or emotional experience as a cure for vagueness. In a requested fictional frame, invention can be appropriate and should remain in that frame.

## Rhythm without a recipe

Read for where the thought moves. Repeated short sentences may conceal a useful relationship; uniformly long sentences may overload the reader. Fix those concrete failures. Do not mechanically alternate sentence lengths, force a long sentence into every paragraph, manufacture fragments, or insert an aside to create supposed human variation.

A confirmation can be "Tuesday works." A careful comparison may need a long sentence. Technical steps can remain parallel. A lyric passage may use repetition intentionally. No cadence statistic decides among them.

## Keep ordinary words and useful structures

There is no banned vocabulary. "Robust" may be the precise statistical term; "framework" may name a real software artifact; "I hope" can express an actual wish; "thank you" can do relational work. Replacing these words with less accurate synonyms can make the text worse.

There is no universal punctuation fingerprint. Em dashes, colons, curly quotes, exclamation marks, parentheses, emojis, and headings can fit. Follow the user's explicit constraints and the piece's context. Keep exact quotations, code, proper names, addresses, mathematical notation, and required house style intact.

A three-item list may contain exactly three necessary things. A genuine contrast, rhetorical question, repeated noun, or first-person statement can be right. Inspect function and meaning before applying any pattern label.

## Match the requested tone without performing it

- Warmth works through a real acknowledgment, an appropriate invitation, or useful care. It does not need repeated reassurance.
- Analytical writing earns its structure with evidence and reasoning. It does not need a pros-and-cons grid or a summary of what it will explain.
- Boldness makes a position clear. It does not require "undeniably," a universal claim, or an aggressive slogan.
- Playfulness uses timing and an apt surprise. It does not require a pun, joke, and emoji in every paragraph.
- Expertise appears in precise distinctions and audience-aware explanation. It does not require named credentials or unnecessary jargon.
- Plainness removes friction. It does not erase nuance, personal feeling, artistic choices, or useful detail.

## Assessment and stopping

Quote a short exact passage, name the observable issue, and explain the reader consequence or a concrete edit. Group overlapping findings. If the only objection is that a word is on someone's AI-tell list, reconsider the finding. If the passage is effective as written, say so.

Do not produce an authenticity percentage or declare that a text will pass detectors. Do not paraphrase repeatedly until all linter candidates disappear. Stop when the requested result is clear, accurate, and suited to its reader.
