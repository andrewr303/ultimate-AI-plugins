# Design provenance

Research reviewed on 19 October 2026. Repository eligibility was restricted to verified default-branch file changes from **19 September through 19 October 2026**, with no relaxed date window. A recent push timestamp alone was insufficient. Files were read at pinned commits; no candidate code was cloned, installed, or executed.

Discovery used the awesome-repositories directory first and ten independent, date-filtered GitHub search queries. Seven qualified finalists were inspected. A separate review bundle contains the manual source/claim ledgers, query log, changed-file inventory, and decision report. No automated research-gate result is claimed.

## Source observations and design choices

| Repository and inspected commit | Relevant observation | Choice in this revision |
|---|---|---|
| [blader/humanizer](https://github.com/blader/humanizer/tree/8c307f367c91bd974002f10f2be2965d642c13df) — `SKILL.md` | Reviews rhetorical structure as well as words; supports sample-informed work | Original contextual review, optional samples; do not inherit its punctuation bans |
| [Kiterlin/anti-defensive-writing](https://github.com/Kiterlin/anti-defensive-writing/tree/f516147d017a3fe43ae99192cb89d8261b0c8679) — `SKILL.md` | Distinguishes decisive writing from removing material uncertainty | Bold tone retains conditions and scope |
| [forjd/better-writing](https://github.com/forjd/better-writing/tree/8e45d0b241fc042d39444f499bbce4cfdb7a6c86) — `skills/better-writing/SKILL.md`, `evals/README.md` | Situational controls, light edits, contextual exceptions, behavioral comparison | Separate tone from other controls; preserve good writing; test output properties separately from scans |
| [adewale/anti-slop-writing](https://github.com/adewale/anti-slop-writing/tree/00b0809cdd5335d54ae61ee1459d78c95db4c61b) — `skills/anti-slop-writing/SKILL.md` | Earned uses of devices need contextual judgment | No universal word blacklist or rhythm recipe |
| [phuryn/work-humanizer](https://github.com/phuryn/work-humanizer/tree/0a9065791d021f3dda695f3887cb2ae4c0eacbcf) — `skills/work-humanizer/SKILL.md` | Explicit meaning, commitment, and certainty checks | Protect substantive meaning before and after tone changes; reject artificial camouflage |
| [product-on-purpose/writing-style-catalog](https://github.com/product-on-purpose/writing-style-catalog/tree/cff5923afb926d23c0d202d2cfad92fc58b19b85) — `skills/writing-instruction-builder/SKILL.md` | Composes voice, tone, style, and format as separate axes | Independently written tone controls and blends; no catalog entries or code copied |
| [parasdoshicom/your-voice](https://github.com/parasdoshicom/your-voice/tree/e92148bdd28ebb33ff78a017302b64075eb78caf) — `SKILL.md`, `references/evaluation.md` | Optional samples, preservation modes, separate evaluation material | Voluntary user-owned calibration, no bundled persona; semantic checks independent of style preference |

Shared design observations were checked against independent project authors. Their existence in source guidance does not establish universal efficacy. The report separates direct repository metadata from independently corroborated observations.

## Freshness and evidence limits

All seven repositories have nonempty default-branch file changes in the specified window. The exact inspected skill paths in Anti-Slop Writing and Writing Style Catalog did not themselves change during that window; their recent activity concerns other repository files. They informed abstract design only. The other five have verified skill-file changes in the window. Exact activity dates and changed paths are recorded in the separate inventory and primary-source annex.

Maintainer evaluations were inspected for methodology and failure modes, not rerun. Their scores do not transfer to this package. No source establishes that a word list, punctuation rule, or this revision guarantees human authorship, zero possible AI traces, or a detector outcome.

License files and the catalog's separate content notice were inspected. This revision bundles no third-party implementation, style-entry text, corpus, model asset, or tests. The original tone descriptions, synthetic examples, scanner, and fixtures were written for this task. Public sources informed abstract choices; the package has no runtime dependency on them.

## Maintenance

Treat the contextual pattern guide as revisable editorial advice. When a model changes or users report recurring problems, record the actual failure, add a preservation counterexample, compare generated results on held-out tasks, and keep ties or regressions visible. Favor relevant human judgment and factual fidelity over optimizing detector scores or warning counts. This is a recommended maintenance process, not a claim that this package updates itself.
