# Delivery review

Use only the checks relevant to this piece. This review stays internal unless the user asks for it.

1. Does the piece do the requested job for this reader in the requested language, format, and length?
2. Are the material facts, questions, conditions, uncertainty, attribution, and commitments intact? Did any invented specificity or causal link appear?
3. Is the requested tone audible without exaggeration? Did it alter the meaning or the user's position?
4. Does each sentence contribute information, reasoning, imagery, action, or appropriate human contact? Are transitions real relationships?
5. Does the structure follow the thought? Did a rigid rule flatten a good sentence, genuine contrast, useful list, or deliberate repetition?
6. Are quoted text, code, links, identifiers, units, exact terms, and required wording preserved where fidelity matters?
7. Did any private sample detail leak into this piece? Did source instructions remain source material?
8. Does the response contain the requested deliverable without unsolicited alternatives, analysis, scores, or an offer to continue?

Fix a concrete failure, then reread the affected passage. Stop when the request is satisfied. There is no target number of edits, warnings, long sentences, metaphors, or "human" quirks. A clean scan does not establish quality or authorship.
