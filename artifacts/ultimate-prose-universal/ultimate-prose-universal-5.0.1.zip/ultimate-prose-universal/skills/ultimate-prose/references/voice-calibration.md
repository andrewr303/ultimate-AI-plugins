# Optional personal calibration

This package contains no author's profile or personal corpus. Any user can use it as-is. Personalization begins only with the current user's instructions or samples they choose to supply or authorize.

## Use what is relevant

For a simple task, the brief and an existing draft are usually enough. For a closer match, use examples with a comparable audience, channel, purpose, language, and degree of formality. One relevant reply can be more useful than many unrelated essays. Do not demand samples as a condition of routine writing or fetch a private account just to calibrate style.

Keep four roles distinct:

- **Brief:** what this piece must do now.
- **Facts:** information authorized for this piece, with its actual date and scope.
- **Voice samples:** wording and structural choices to learn from, with their context.
- **Feedback:** explicit preferences and reactions, including exceptions.

A delivered message shows wording, not proof of unaided authorship. A prepared biography, generated demonstration, summary, or repeated quotation is not a new independent sample. Engagement statistics do not establish a person's preferred style.

## Build a provisional style card

Only if useful, infer a few observations such as:

```text
Relevant scope: friendly project updates to existing collaborators.
Opening: usually begins with the changed result.
Detail: names the relevant limitation without a long preamble.
Warmth: brief, specific acknowledgment.
Rhythm: connected reasoning; short confirmations stay short.
Explicit preferences: retain contractions; no emojis in these updates.
Uncertain inference: too few examples to infer signoff preference.
```

This example is synthetic. It is not the default voice of this skill. Describe observations, not identity traits or universal laws. Keep the card provisional and task-specific. Avoid percentages, cadence targets, arbitrary word budgets, or subjective authenticity scores.

Use a style card only within the task unless the user asks to save it through an authorized storage mechanism. Do not silently modify this shared package or create a persistent profile. If the user requests a reusable profile, write a separate user-owned artifact that contains preferences and abstract observations, without private messages or unrelated biography.

## Adapt without leaking

Learn how a sample explains, addresses a reader, qualifies a claim, or handles a relationship. Do not transplant its names, contacts, URLs, financial details, clients, sensitive history, memories, or claims into a different piece. Writing to a person is different from writing as that person. A public sample still does not authorize reusing an unrelated personal disclosure.

Historical facts need current support. A profile's update date does not make every fact inside it current. Prefer the live brief and relevant primary record; if a material conflict remains, ask once, mark a placeholder, or omit the uncertain fact. Do not merge incompatible versions into a confident claim.

Never add typos, fake vulnerability, slang, invented emotions, or deliberate awkwardness to simulate a person. Preserve genuine distinctive choices when they serve the piece. Do not smooth every sentence into the same polite professional register.

## Stable voice and changing tone

Voice observations describe tendencies within relevant evidence; tone expresses the needs of this particular moment. A user's usual directness can coexist with tenderness in a personal note or formality in a letter. An explicit tone request overrides an inferred default, while exact protected text and factual meaning remain intact.

If a sample conflicts with an explicit preference, follow the explicit preference. If the user says "keep my voice," preserve effective quirks rather than applying the plain/direct default as a homogenizing filter. If no sample fits, use the requested tone and current draft without claiming a close personal match.

## Check the result

Review factual fidelity and voice fit separately. First compare the substantive claims, questions, conditions, commitments, and protected strings. Then check whether the wording reflects relevant samples without importing their content. Finally check the requested tone, channel, length, and output shape.

For an evaluation, keep examples used for calibration separate from prompts used for judging. Allow ties and unchanged strong passages. A small model-assisted review is useful feedback; it does not prove a user's preference, human authorship, universal quality, or detector performance.
