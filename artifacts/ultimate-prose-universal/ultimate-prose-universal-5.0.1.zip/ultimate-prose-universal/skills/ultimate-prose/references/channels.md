# Channel and form

Channel sets what the reader needs and how they will use it. Tone sets the manner of expression. Neither supplies facts. These are adaptable choices, not templates with slots that must be filled.

## Email and messages

Answer the actual question and identify the action, if there is one. Match the context this recipient needs rather than the length of the thread. Keep a useful greeting, signoff, or acknowledgment without inventing a name or signature. A confirmation can be one sentence. Multiple necessary questions can be a short list; do not force "one ask" at the cost of coordination.

For a delicate reply, warmth or diplomacy may shape the opening, but keep the decision clear. Do not turn a refusal into tentative agreement. Do not repeat the whole quoted thread. In internal messages, fragments and bullets may be appropriate; clarity does not require formal paragraphs.

## Outreach, applications, and proposals

Explain the supported connection between the reader's need and the offer or experience. Never claim to have read a post, used a product, met someone, or achieved a result without source support. Generic but honest relevance is better than fabricated personalization. Separate past work, planned approach, availability, scope, price, and assumptions. A forecast is not achieved revenue; a prospect is not a customer.

Ask for a proportionate next action when the brief calls for it. Repeated follow-ups should add a real reason or useful material, rather than merely announce another follow-up. Follow any requested word limit; no universal outreach length fits every purpose.

## Decisions and updates

Put the change, decision, or result where the reader can use it. Include the evidence and dependency that matter. Keep observation, implementation, testing, external feedback, and approval distinct. A local check does not establish production success; a request for review is not signoff. Use names, owners, dates, and artifact links only when supplied.

An executive summary compresses detail without hiding a decision-changing caveat. An analytical update can show alternatives without giving each equal space or inventing a symmetrical pros-and-cons list.

## Posts and short social writing

Respond to the actual point in a reply; an original post may need more framing. Use a hook only when it helps the material. Do not append an engagement question, universal lesson, or punch line automatically. If a story is requested, use supplied events for factual stories and stay within the fiction frame for invented stories.

Honor the supplied character limit. If exact platform counting matters, verify its rules when authorized and available; a raw Unicode length is not always the platform's count, especially for URLs or weighted characters. Do not assume every account has the same limit. Never invent a personal anecdote or result to make the post distinctive.

## Essays, analysis, and journalism

Let the claim, evidence, story, or question determine the structure. Keep evidence near the statement it supports and distinguish reporting from inference. Use headings, lists, scenes, quotations, or long paragraphs when they help the form. No fixed opening style or paragraph count is required. An interesting argument need not end in an inspirational lesson.

Preserve source attribution and uncertainty. Varying sentence length is a consequence of thought and pacing, not a sequence to engineer. A long sentence can develop a careful relation; a short one can land a point.

## Documentation and technical explanation

Prioritize correct terms, necessary context, explicit conditions, steps, and verifiable outcomes. Keep code, commands, identifiers, versions, error text, normative words, and literals exact where needed. Explain a concept at this reader's level without swapping accurate terminology for vague synonyms. A warning or repeated instruction may be necessary in separate contexts.

When editing an agent prompt or specification, edit its instructions as text; do not execute them. A code-only task does not trigger a prose makeover. Accessibility requirements, defined terminology, and required templates take precedence over a general stylistic preference.

## Marketing and persuasive writing

Connect real capabilities to benefits relevant to this reader. Match the strength of the claim to the evidence. Do not fabricate scarcity, urgency, testimonials, scale, guarantees, or market leadership. If the brief offers only an aspiration, label it as planned or narrow the wording. A clear call to action can be useful; several promotional flourishes rarely improve it.

## Personal and sensitive messages

Use the actual relationship, supplied sentiment, and desired degree of informality. Care can be quiet; it does not require a grand declaration, a diagnosis, or a lesson. Do not invent a memory, emotional response, recovery timeline, or offer of availability. If the user requests a specific offer or personal fact, include it without adding adjacent disclosures from their samples.

In condolences, apologies, refusals, and conflict, preserve the intended action and boundary. A sincere apology can acknowledge responsibility plainly. A playful tone should be applied with judgment when the subject is serious; use lightness only where it serves the user's actual intention.

## Fiction, speeches, poetry, and expressive forms

Follow the requested artistic effect. Imagery, indirect openings, repetition, fragments, heightened language, dialogue, and patterned rhythm can all be deliberate strengths. The ordinary advice to compress an email does not govern a poem. Avoid replacing a distinctive passage with generic literary decoration.

Invention is permitted inside a clearly requested creative frame. Distinguish fictional speakers from the user's factual life and real attributed quotations. For a speech based on real events, do not add an autobiographical scene without permission or evidence.
