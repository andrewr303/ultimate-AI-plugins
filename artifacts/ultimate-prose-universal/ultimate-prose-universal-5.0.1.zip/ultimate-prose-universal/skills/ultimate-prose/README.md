# Ultimate Prose 5.0.1

Write, edit, or assess prose in the tone you request. Start with plain/direct, warm, analytical, bold, playful, expert, or any custom blend. No personal profile or sample corpus is bundled. Optional calibration uses your own relevant examples.

Try: "Make this warm but firm; keep the refusal clear," or "Write an expert explanation in everyday language." Tone can be combined with formality, detail, length, and a requested format. Existing effective voice survives a light edit. The skill does not guarantee an authorship or detector result.

Import the `.skill` archive through a compatible host, or extract this directory into the host's documented skill location. Host-specific import and automatic triggering must be checked in that host. Install one copy of the skill.

Python is optional. From this directory:

```sh
python scripts/lint.py draft.txt --genre email --tone warm
python scripts/lint.py draft.txt --json
python scripts/lint.py draft.txt --straight-quotes --no-em-dash --strict
python -m unittest discover -s tests -v
```

The scanner uses the standard library, reads local text, and never rewrites or transmits it. All findings are contextual REVIEW candidates. Typography conventions are off unless selected; strict mode exits 1 only for selected convention findings. Exit 2 means an input/usage error. The v5 JSON schema and CLI differ from v4; see `--help`. `--detect` is an editorial-report alias, never an authorship detector.

Small English phrase checks and heuristic source masks cannot establish truth, meaning preservation, tone fit, quality, or origin. Review findings in context. If Python is unavailable, use the editorial workflow manually.

See `references/tones.md` for presets and blends, `references/voice-calibration.md` for optional personal use, `references/research.md` for dated public sources, and `references/validation.md` for what was checked in this release.
