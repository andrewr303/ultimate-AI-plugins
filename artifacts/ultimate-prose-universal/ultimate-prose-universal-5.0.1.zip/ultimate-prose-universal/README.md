# Ultimate Prose Universal 5.0.1

A writing skill for anyone's personal use. It writes, edits, polishes, and assesses prose with a flexible tone and an emphasis on accurate meaning, natural movement, and useful detail. It contains no bundled personal voice profile or private corpus.

The six core tones are **plain/direct, warm, analytical, bold, playful, and expert**. Additional presets and custom blends are supported. Tone can be combined with formality, detail, length, and an optional voice sample. No profile setup is required.

Try requests such as:

- "Make this warm but firm. Keep the refusal clear."
- "Write an expert explanation for a beginner, without jargon."
- "Use a playful tone with dry humor. Keep it under 80 words."
- "Make this analytical and concise. Preserve every estimate and caveat."
- "Keep my voice from these examples, but make this note more formal."
- "Assess this passage for formulaic phrasing. Don't rewrite it."

Plain/direct is the fallback for new writing without a tone request. An existing draft's effective voice is preserved unless you ask to change it. There is no forced business register, punctuation ban, cadence quota, or universal list of forbidden words.

## Files and installation

- The **plugin ZIP** contains one `ultimate-prose-universal/` directory with a portable Agent Plugins 1.0 `plugin.json` and `skills/ultimate-prose/SKILL.md`.
- The **standalone `.skill`** is a ZIP-format archive containing one `ultimate-prose/` directory with `SKILL.md` at its root and the same references, scanner, and tests.

Use your host's supported plugin or skill import flow. For a filesystem-based agent-skill host, extract the standalone archive and place the `ultimate-prose/` directory in that host's documented skill location. Install one format; installing both can expose duplicate skills. Hosts differ in archive support. No host installation or automatic-trigger test is implied by these instructions.

The plugin source export also includes an identical standalone copy at `assets/ultimate-prose-universal-5.0.1.skill` for use in another compatible host.

The skill works as instructions without Python. Its optional scanner uses only the Python standard library, reads local text, and does not rewrite or transmit it. From the skill directory:

```sh
python scripts/lint.py draft.txt --genre email --tone 'warm but firm'
python scripts/lint.py draft.txt --json
python scripts/lint.py draft.txt --straight-quotes --no-em-dash --strict
python -m unittest discover -s tests -v
```

The last scanner example opts into two house-style conventions. They are off by default. `--strict` exits 1 only for selected convention findings; ordinary editorial findings remain advisory. Exit 2 means an input or usage error. `--detect` is a legacy name for an editorial report and never predicts authorship. The CLI was simplified in v5; it does not accept all legacy scanner flags or provide the old JSON schema. Run `--help` for supported options.

Scanner phrase checks are limited and primarily English. They do not verify facts, determine semantic fidelity, or judge whether a tone succeeds. Source masking is heuristic. A clean scan is not proof of quality or origin.

## Personalization and privacy

Use the skill without samples, or supply examples relevant to your task. It learns abstract style choices within the task rather than importing biography or private facts. A reusable personal style card is optional and should be saved separately only at your request. The package does not install hooks, access accounts, send messages, or publish anything by itself.

Drafts, examples, and quoted instructions stay source material. The current request controls the work. Private material should not enter public research queries. Any actual model or host processing remains subject to the host you use; this package is not an independent privacy service.

## What changed from 4.2

The named profile, corpus aggregates and source identifiers, personal-context references, author-specific scanner, inherited business register, punctuation defaults, and cadence assumptions were removed. The shared workflow retains meaning preservation, protected-source handling, proportionate editing, and specific assessments. New tone controls, custom blends, optional user calibration, a smaller advisory scanner, and fresh regression prompts replace the former personal defaults.

The old review bundle and its evaluation results are not included or relabeled as v5 evidence. Current research provenance is summarized in the skill's `references/research.md`. A separate review bundle records this revision's actual checks and their limits.

The target is excellent writing without formulaic habits. No package can establish zero possible AI traces or guarantee an AI-detector outcome. This skill does not introduce fake mistakes or experiences to simulate human authorship.
