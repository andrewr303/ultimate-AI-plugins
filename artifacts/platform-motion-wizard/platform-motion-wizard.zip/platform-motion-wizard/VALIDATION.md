# Validation notes

This document describes the package's verification contract. The release evidence is recorded in validation/release-checks.json and validation/lab-results.json.

## What local validation checks

- Portable manifest, Claude compatibility identity, skill frontmatter and names, optional OpenAI metadata, assets, contained local references and files.
- Exact preservation of the supplied skill, transcript, original icon, and archived agent metadata using SHA-256 records.
- Source and claim ledger references, independent-author metadata, and explicit manual-mode status. This checks data integrity; source review is still a human/agent responsibility.
- ZIP containment, traversal/symlink/duplicate entries, intended components and reproducible package contents.
- Regression fixtures with malformed packages, changed preserved bytes, bad metadata and unsafe archives.

The validation script is an authored structural checker, not an official host validator or an automated factual research gate. No verified_claims.json is produced.

## Behavioral evidence

The offline lab was exercised using already-installed Playwright and Chromium on Linux. Seven check groups cover selection via pointer/keyboard; native dialog replay, Escape and focus return; live reduced motion during entry; pending/cancel/stale response/failure/success; narrow dark appearance; synthetic lifecycle cleanup; and absence of script errors/external requests.

A portable copy of the browser check lives at tests/check_lab.py. It requires Playwright and an available Chromium browser; these are optional development tools and are not runtime dependencies of the plugin or lab. It does not install either one. Run it in an existing browser-test environment:

```sh
python tests/check_lab.py --output /absolute/path/to/evidence
```

Synthetic pagehide/pageshow events do not prove actual back-forward cache restoration. Stable screenshots were inspected for appearance; they are not timing evidence. The captured [desktop](validation/lab-desktop.png) and [narrow dark](validation/lab-mobile-dark.png) states are included for review.

## Skill behavior fixtures

tests/skill-scenarios.json lists positive, mixed, negative and adversarial prompts with expected routing and acceptance. These are reviewer fixtures, not a claim that an agent-host evaluation was run. Inspect them after changing descriptions/router boundaries.

## Limits

The installed Codex CLI exposes plugin management but no package-validation command; Claude Code is not installed. No native SDK build, physical mobile device, assistive-technology session, production app integration, frame-rate benchmark, host plugin installation, or public submission was performed. The plugin is a ZIP/source deliverable. Implementation skills require those checks in the actual product when relevant.
