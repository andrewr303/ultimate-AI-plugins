# Interaction contract

Use only fields needed for the flow.

- Task and scope:
- Existing primitive / framework / installed version:
- Trigger and input methods:
- Stable domain states and guards:
- Immediate acknowledgment:
- Actual work start / success / failure:
- Stable source and destination identity:
- Visual start / end:
- Property owner:
- Motion role / units / origin:
- Cancellation / reversal / newer event wins:
- Stale response / retry / rollback:
- Focus / screen reader / hit testing / scroll:
- Normal / reduced / live preference change:
- Resize / RTL / zoom / content growth:
- Affected files:
- Reproduction and observable acceptance:
- Evidence actually collected:
- Remaining unverified behavior:
