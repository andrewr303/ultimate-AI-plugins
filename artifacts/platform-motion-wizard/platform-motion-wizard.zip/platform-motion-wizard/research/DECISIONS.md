# Design decisions and provenance

Read the [main report](outputs/research-decision-report.md), [native supplement](native/outputs/native-accessibility-research.md), and [activity table](../references/research-snapshot.md).

| Requirement | Adopted idea and evidence | Original implementation |
| --- | --- | --- |
| Immediate feedback and coherent states | User request and complete supplied skill; pinned input observations are qualified in main report | controls, async, contracts |
| Interruptible presence | clm_presence, clm_reentry, clm_cancel in main claim ledger | state-lifecycles reference, overlay/web/gesture checklists |
| Live reduced-motion policy | clm_live, clm_snapshot; native_clm_001 and native_clm_003 | accessibility and native specialists; lab policy |
| Semantic exits | native_clm_002 plus original skill | explicit overlay focus/inert/presence ownership |
| Current coding-agent workflow | clm_evidence; user request for routing and multiple skills | fresh router, focused skills, bounded agents and temporal review |
| Restrained vocabulary | Preserved source skill's authored starter ranges | opt-in token example and system skill |
| Honest performance claims | User request and authored verification policy | profiling specialist and evidence report |
| Reviewable deliverable | User request for full ZIP | manifests, provenance hashes, package validation and regression fixtures |

No third-party implementation or skill is incorporated. Source-specific constraints and rights observations remain in the reports' Unresolved sections. The final architecture is original; source review informed the behavioral invariants.
