# Changelog

## 1.0.0 — 2026-10-21

- Introduce platform-motion-wizard with a routing skill and focused product-interaction workflows.
- Preserve the complete supplied polish-platform-motion skill and original supporting material.
- Add controls, overlays, navigation, gesture, loading/streaming, accessibility, native, web, motion-system, audit, specification, research, performance, live-lab, and review skills.
- Add bounded design/implementation/accessibility/performance/review agents and common handoff contracts.
- Add research ledgers and commit-level activity observations, original state/verification references, templates, and an offline interaction lab.
- Add local package/provenance validation, archive building, and malformed-package regression checks.
