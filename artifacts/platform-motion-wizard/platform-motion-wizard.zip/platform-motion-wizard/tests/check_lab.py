"""Local lab smoke checks; uses already-installed Playwright and Chromium.

No browser or dependency installation is performed. These checks exercise the
example only, not an application into which it may later be integrated.
"""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
import argparse
import json
import shutil
import tempfile

from playwright.sync_api import sync_playwright


LAB = Path(__file__).resolve().parents[1] / 'examples' / 'motion-lab'


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Evidence directory outside the plugin')
    parser.add_argument('--browser', help='Existing Chromium executable')
    parser.add_argument('--no-sandbox', action='store_true', help='For an isolated container that requires it')
    args = parser.parse_args()
    evidence = args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix='platform-motion-lab-'))
    plugin_root = Path(__file__).resolve().parents[1]
    if evidence == plugin_root or plugin_root in evidence.parents:
        parser.error('Choose an evidence directory outside the plugin')
    evidence.mkdir(parents=True, exist_ok=True)
    executable = args.browser or shutil.which('chromium') or shutil.which('chromium-browser')
    launch_options = {'args': ['--no-sandbox'] if args.no_sandbox else []}
    if executable:
        launch_options['executable_path'] = executable
    server = ThreadingHTTPServer(
        ('127.0.0.1', 0), partial(QuietHandler, directory=str(LAB))
    )
    Thread(target=server.serve_forever, daemon=True).start()
    checks, script_errors, console_errors, requests = [], [], [], []
    try:
        with sync_playwright() as runtime:
            browser = runtime.chromium.launch(**launch_options)
            page = browser.new_page(
                viewport={'width': 1140, 'height': 1000},
                reduced_motion='no-preference'
            )
            page.on('pageerror', lambda error: script_errors.append(str(error)))
            page.on('console', lambda message: console_errors.append(message.text)
                    if message.type == 'error' else None)
            page.on('request', lambda request: requests.append(request.url))
            origin = f'http://127.0.0.1:{server.server_port}'
            page.goto(origin)
            page.wait_for_function("document.documentElement.dataset.reduce === 'false'")

            page.locator('#favorite').click()
            assert page.locator('#favorite').get_attribute('aria-pressed') == 'true'
            page.locator('#favorite').press('Space')
            assert page.locator('#favorite').get_attribute('aria-pressed') == 'false'
            checks.append('pointer and keyboard toggle selection')

            page.locator('#openDialog').click()
            assert page.locator('#detail').evaluate('(d) => d.open')
            assert page.locator('#closeDialog').evaluate('(d) => document.activeElement === d')
            page.locator('#replayDialog').click()
            page.wait_for_timeout(60)
            assert page.locator('#detail').evaluate('(d) => d.open')
            assert page.locator('#closeDialog').evaluate('(d) => document.activeElement === d')
            page.keyboard.press('Escape')
            page.wait_for_function("!document.querySelector('#detail').open")
            assert page.locator('#openDialog').evaluate('(d) => document.activeElement === d')
            checks.append('native dialog entry/replay/Escape and focus return')

            page.locator('#overlayDuration').fill('320')
            page.locator('#openDialog').click()
            page.emulate_media(reduced_motion='reduce')
            page.wait_for_function("document.documentElement.dataset.reduce === 'true'")
            assert page.locator('#detail').evaluate('(d) => d.open')
            assert page.locator('#detail').evaluate('(d) => d.getAnimations().length') == 0
            page.keyboard.press('Escape')
            page.locator('#reduce').check()
            page.emulate_media(reduced_motion='no-preference')
            page.wait_for_function("document.documentElement.dataset.reduce === 'true'")
            page.locator('#reduce').uncheck()
            page.wait_for_function("document.documentElement.dataset.reduce === 'false'")
            checks.append('live OS reduction settles entry; comparison only reduces further')

            page.locator('#run').click()
            assert page.locator('#run').get_attribute('aria-disabled') == 'true'
            assert page.locator('#asyncRegion').get_attribute('aria-busy') == 'true'
            page.locator('#run').dispatch_event('click')
            page.locator('#cancel').click()
            canceled = page.locator('#asyncStatus').text_content()
            page.wait_for_timeout(1300)
            assert page.locator('#asyncStatus').text_content() == canceled
            for outcome, text in [('error', 'Simulation failed'), ('success', 'Simulation succeeded')]:
                page.locator('#outcome').select_option(outcome)
                page.locator('#run').click()
                page.wait_for_function(
                    '(text) => document.querySelector("#asyncStatus").textContent.includes(text)',
                    arg=text
                )
                assert page.locator('#asyncRegion').get_attribute('aria-busy') == 'false'
            checks.append('pending, duplicate guard, cancellation, stale exclusion, failure and success')

            page.screenshot(path=str(evidence / 'desktop.png'), full_page=True)
            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
            page.screenshot(path=str(evidence / 'mobile-dark.png'), full_page=True)
            checks.append('narrow viewport without horizontal overflow; dark appearance captured')

            page.locator('#run').click()
            page.evaluate("window.dispatchEvent(new Event('pagehide'))")
            assert page.locator('#run').get_attribute('aria-disabled') == 'false'
            assert 'leaving' in page.locator('#asyncStatus').text_content()
            page.evaluate("window.dispatchEvent(new Event('pageshow'))")
            page.emulate_media(reduced_motion='reduce')
            page.wait_for_function("document.documentElement.dataset.reduce === 'true'")
            page.wait_for_timeout(1300)
            assert 'leaving' in page.locator('#asyncStatus').text_content()
            checks.append('synthetic pagehide/pageshow cancellation and preference resubscription')

            assert not script_errors, script_errors
            assert not console_errors, console_errors
            assert all(url.startswith(origin) for url in requests), requests
            checks.append('no script errors, console errors or external HTTP requests')
            browser.close()
    finally:
        server.shutdown()
        server.server_close()
    record = {
        'browser': 'Chromium via installed Playwright; headless Linux',
        'checks': checks,
        'errors': script_errors + console_errors,
        'limitations': [
            'No real mobile hardware, assistive-technology, native-platform or frame-rate validation.',
            'Screenshots establish stable appearance only.',
            'Synthetic page lifecycle events do not establish actual back-forward cache behavior.'
        ]
    }
    (evidence / 'results.json').write_text(json.dumps(record, indent=2))
    print(json.dumps({'evidence_directory': str(evidence), **record}, indent=2))


if __name__ == '__main__':
    main()
