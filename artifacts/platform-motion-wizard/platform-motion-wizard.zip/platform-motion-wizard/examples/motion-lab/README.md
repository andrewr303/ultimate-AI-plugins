# Local interaction lab

Open `index.html` in a current browser, or serve this directory using an existing
local development server. Python's standard-library option is:

```sh
python -m http.server 8765 --bind 127.0.0.1 --directory examples/motion-lab
```

Then open `http://127.0.0.1:8765`. The page has no external requests, dependencies,
analytics, persistence, audio, or real service operations. Its delayed response is
explicitly a local simulation; do not use that delay in production logic.

## Try these comparisons

1. Activate the saved toggle with pointer, Space, and Enter. Selection changes
   immediately while visual feedback accompanies the change.
2. Adjust durations, open the native dialog, replay its entry, press Escape, and
   reopen it. Check first-frame clickability and focus placement/return.
3. Run and cancel the simulation; start another run immediately. Try both outcomes.
   A canceled response must never overwrite the later result.
4. Turn on **Use no motion**. Repeat every operation. Change the system reduced-
   motion preference while the dialog is opening; movement should stop without
   closing the dialog or changing semantic state. The page cannot force movement
   when the system requests reduced motion.
5. Repeat at a narrow viewport, with dark appearance, and with keyboard only.

The native dialog closes immediately. This intentionally avoids teaching an exit
delay or a timer-dependent semantic lifecycle. It demonstrates a safe baseline;
use the overlay skill when a product genuinely needs an animated exit.

The durations are original tuning examples derived from this plugin's existing
starting ranges. They are not measurements of Apple software or universal values.
This small page does not verify your application's actual stack, assistive
technology, layout, backend, native platform, or performance. Review the product
itself after using the lab.
