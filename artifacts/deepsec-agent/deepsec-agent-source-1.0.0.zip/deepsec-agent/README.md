# DeepSec Agent — improved local coding-agent edition

This derivative preserves the uploaded DeepSec TypeScript monorepo and adds a standalone local plugin for Codex, Claude Code, and Kimi Code in `agent-plugin/`. The new bridge runs without installing the original model/cloud dependency tree.

```sh
node agent-plugin/bin/deepsec-agent.mjs scan --root /absolute/repository --out findings.json
node agent-plugin/scripts/configure-host.mjs --host kimi --root /absolute/repository --out /absolute/new-kimi-plugin
npm --prefix agent-plugin test
```

Start with [the plugin guide](agent-plugin/README.md) and [host installation](agent-plugin/docs/HOSTS.md). Repository comparisons, pinned implementation evidence, unresolved claims and validation records are in `research/`. The local bridge reuses the uploaded matcher registry, adds file/process bounds, explicit incomplete coverage, optional complementary engines, JSON/Markdown/SARIF reports, baselines, scripting, and host-mediated review.

The original scanner/processor/cloud pipeline remains in `packages/`, with its [original README](README.upstream.md) and existing docs. Those commands retain their original dependency/setup and cost behavior. The new local bridge does not start them automatically.

Modified upstream files in this derivative: root README.md (this guide) and package.json (added agent scripts only). New plugin/runtime/research files are original additions; bundled matcher logic is generated unchanged from uploaded source. Embedded `.deepsec` state and workspace-specific agent configuration are excluded; packaged CLI documentation is preserved. Supplied LICENSE and NOTICE are retained. This is not an official Vercel product.
