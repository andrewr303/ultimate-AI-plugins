---
type: tool_used
tool: Skill
input_match: "glass"
min: 0
max: 0
arm: both
---
