# Issue Assistant

A private, skills-based plugin for coding agents using the connected Linear and GitHub integrations. It adds no server and stores no credentials. Linear is optional when GitHub Issues is the tracker; GitHub supplies PR and source context in both modes.

Start with: “Use issue-assistant for owner/repo and Linear team/project (or GitHub Issues). Reconcile 28 days, apply updates, then grill me.” The default is 28 days; request 14, 56, 90, or a date range. Older linked evidence is followed as needed.

The workflow reads issues, merged PRs and patches, reviews, code, tests, release/deployment evidence where acceptance requires it, documentation, PR ledgers, and available authorized agent-session material. It distinguishes completed, partially completed, changed, regressed, duplicate, and untracked work. It applies supported tracker changes, verifies the results, and then asks one question about the highest-priority actionable issue. Ask it to fix, investigate, split, skip, or defer an issue at any time.

Five skills are included:

| Skill | Purpose |
| --- | --- |
| issue-assistant | Audit, apply changes, then interview in priority order |
| reconcile-issues | Source-backed reconciliation for Linear or GitHub Issues |
| grill-issue | One issue, one unresolved decision, one question at a time |
| break-down-issue | Verifiable vertical subtasks with acceptance and dependencies |
| daily-issue-sync | Unattended reconciliation without interviewing or coding |

Added capabilities include acceptance-criterion coverage, duplicate suppression, revert checks, dependency-aware priority, decision memory, human-edit conflict detection, missing-test/docs/migration follow-ups, resumable mutation journals, and ready-to-code handoffs.

The separate hosted automation is created through the host scheduler. Packaging or installing this plugin alone does not create a scheduled job. See automation/daily-prompt.md for its reusable instruction template. Hosted runs keep durable state in a scoped tracker ledger and remote markers, rather than assuming temporary workspace files survive.

The Python helper is optional and offline. It computes windows and fingerprints, gates agent-supplied completion evidence, ranks queues, and keeps a local journal. It does not fetch PRs, understand code, or change trackers. The coding agent performs that work through connected tools. Run `python -m unittest discover -s tests -v` for fixtures. No third-party Python dependencies are required by the helper.

This is a private account/workspace package with existing app bindings, not a public-directory submission package. Integrations and host policies must permit the requested actions. General past coding-session access is not guaranteed; supplied exports, authorized local history, and repository ledgers are supported when available. Missing sources are reported. A merged PR alone never proves acceptance, deployment, or completion.
