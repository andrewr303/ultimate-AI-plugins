---
name: grill-issue
description: "Use to interrogate the highest-priority actionable Linear or GitHub issue, asking exactly one question at a time and turning answers into implementation, investigation, subtasks or a recorded decision."
---

# Grill one issue

Use the refreshed queue from reconciliation or resolve the specified issue. Read issue, parents, blockers, linked PRs, current implementation and prior decisions before asking. Discover facts yourself when code/docs can answer them. Ask the user only for a decision, missing experience, constraint, tradeoff or acceptance expectation that needs their judgment.

For the active issue, state its ID/link, why it comes next, what is known, and the single decision preventing progress. Ask **exactly one question in the turn** and wait. Use a one-question input tool if supported, otherwise plain text. A question may have two or three concise choices and a recommendation, but do not bundle independent questions or sneak a questionnaire into a bullet list. Be direct and respectful; grill assumptions, not the person.

Start at the most consequential uncertainty: actual user problem/outcome, required behavior, invariant, scope boundary, dependency, failure mode, or acceptance test. Ask deeper follow-ups one at a time only when the answer exposes another unresolved decision. Do not demand that the user recite technical facts you can inspect. Do not repeat an answered question or ask for permission already granted.

Recognize direction in any wording:

- **Implement/fix:** inspect repository instructions, make the scoped change, run relevant checks, and add a real handoff/result to the issue. Report unavailable execution. Keep the issue open when acceptance remains unverified. Then resume this issue or the next eligible issue.
- **Research/context:** investigate code, docs, PR history and available sessions; add concise evidence and revised unknowns, then ask the next single decision question if needed.
- **Split/subtasks:** follow [break-down-issue](../break-down-issue/SKILL.md); create/link concrete subissues within the requested scope. Return to the next necessary decision or implementation step.
- **Skip/defer:** record why and any user-supplied resumption condition/date, leave status accurate, and move to the next eligible issue. “Not now” is not cancellation or a due date.
- **Correct/reprioritize:** apply the user's clarified intent, record the decision, refresh dependencies and queue.

Before advancing, persist the resolved decision, rationale, evidence, open uncertainty, implementation/validation outcome, and exact next action in a managed issue section/comment or the configured ledger. Stop questioning when the issue is actionable; provide a ready-to-code packet containing expected behavior, constrained scope, code entrypoints, acceptance checks, dependencies and remaining explicit unknowns. Do not invent product decisions to fill blanks.

If the queue is empty, say so with reconciliation coverage. If every item is blocked, select the highest-priority blocker/decision and ask one question about it. In unattended mode never invoke this skill; preserve the unresolved decision for the next interactive session.
