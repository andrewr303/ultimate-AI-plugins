---
name: daily-issue-sync
description: "Use for an explicitly scheduled or unattended issue reconciliation run that analyzes merged PRs and recent actions and creates or updates Linear issues, or GitHub issues when configured, without user input."
---

# Unattended issue reconciliation

Run [reconcile-issues](../reconcile-issues/SKILL.md) in apply mode using the saved repository allowlist, tracker IDs and policy. The scheduled task authorizes scoped evidence-backed tracker maintenance. Do not ask interview questions or wait for interactive preferences. Do not start coding, merge PRs, deploy, contact other people, or change access. Preserve decisions requiring the user as unresolved findings for the next interactive issue-assistant session.

Load the remote scoped ledger and recover pending/uncertain operations first. Capture a fixed UTC scan end. On first run baseline 28 days; later cover all time since each last completed checkpoint plus at least 48 hours overlap, rechecking the rolling baseline and older linked work when needed. Inspect merged PRs, current source and tests, follow-up/revert PRs, reviews/comments, recently changed issues and their comments, linked docs/PR ledgers and available authorized session actions. Distinguish unavailable histories from no actions. Follow pagination/partition capped results; report partial coverage honestly.

Apply supported completions, scope add-ons and relationships; create genuinely missing issues after duplicate search. Check every acceptance criterion and required deployment/manual evidence before closure. Record current code contradictions and regressions. Preserve human fields and explicit priorities. Use remote concern/operation markers, journal intent, verify writes and persist receipts. Recover timed-out creates rather than blindly retrying. A repeated unchanged finding must not create another issue or comment.

Acquire/recheck the scoped writer lease and skip contested writes. Persist per-source coverage, verified changes, uncertainties and retry queue. Never advance past incomplete work. If the host cannot read/write required sources or persist state, report the concrete failure and leave pending work recoverable; don't assume next run can recover missing local files.

Return a compact digest linking changed issues, reason/evidence, high-priority blockers, pending decisions, coverage and any failed operations. When there are no changes or newly material blockers, use the host's silent-completion convention if available. Don't repeatedly notify about unchanged blockers.

This skill does not schedule itself. A separate hosted automation must be created when requested. Before scheduling, make harmless successful reads on all required external apps. Use a 24-hour recurrence when requested and the user's timezone for presentation. The reusable self-contained prompt is [daily-prompt](../../automation/daily-prompt.md); copy the resolved target IDs into the actual task so it can run even when local plugin files are absent.
