---
name: reconcile-issues
description: "Use to audit Linear or GitHub issues against merged PRs, code, tests, documentation, PR ledgers and available agent history, then apply supported status, scope and missing-issue updates."
---

# Reconcile issues

Read [providers](references/providers.md) and [state and evidence](references/state-and-evidence.md). These define write preservation, completeness, deduplication, and failure recovery. Tool names differ by host: discover the actual exposed schema before calling a tool. Use existing authenticated integrations; do not add a server or request a token when the connected tools suffice.

## Establish coverage

- Resolve authorized target IDs and primary tracker. Pin run ID, UTC end timestamp, default-branch SHA per repo, mode (apply or preview), and requested range. A first run defaults to 28 days. Respect 14-day, longer, or explicit ranges. Follow older linked material as far as needed and log extensions.
- Load previous run manifest and verified receipts. An incremental scan starts before the last *completed* checkpoint with at least 48 hours of overlap; never clip away a missed interval. If state is absent, repeat the baseline and recover remote markers. Track PR merges, PR updates/comments/reviews, issue updates/comments, relevant docs/ledgers, and available session actions separately. Not every service exposes a full action audit log.
- Fetch all scoped open/backlog issues, recently completed/closed issues, and parents/children/duplicates/linked work outside the time window as needed. Search open **and closed** issues before creating missing work. Paginate all sources. Partition capped searches by disjoint time ranges; use list APIs if one interval remains capped. Record an unresolved cap as incomplete, never as exhaustive coverage.
- Enumerate merged PRs by `merged_at`, not creation date. Also inspect relevant older PRs changed since the checkpoint. A search hit marked closed still needs merge-state verification. Include bot/dependency PRs where their consequences matter. Inspect PR body, full changed-file listing/patches, relevant files at merge and current pinned head, reviews, comments, tests/checks, follow-up/revert PRs, and release evidence where applicable. Missing/truncated/binary patches require source fallback or an explicit gap.
- Discover actual repo docs and ledgers using filenames/search: README, architecture and product specs, ADRs, changelog/release notes, migrations, implementation plans, PR ledgers, worklogs, and authorized session exports. Read project-linked docs where accessible. Local session/history access must be scoped to this project and authorized; do not scan unrelated home directories or assume a general chat-history API. Session statements are leads, not proof of merged work.

## Build the evidence map

For each issue, map every acceptance criterion to implementation paths/lines, PR URL and merge SHA, test/check evidence, current-head state, and required release/manual acceptance evidence. Mark each criterion met, partial, missing, contradicted, or unknown. Keep observation separate from inference. Record what was not accessible.

For each PR, compare before/after behavior against issue scope. Find: completed-but-open work; partially delivered scope; changes that invalidate an existing description; integration follow-ups; regressions/reverts; missing tests/docs/migrations/rollouts; untracked concrete bugs and agent-discovered work. Follow dependencies across PRs. A PR mention, closing keyword, checkmark, TODO, or coding-agent claim is not completion proof. Deployment and human acceptance remain required when the issue says so.

Classify each concern as `complete`, `partial`, `scope_drift`, `missing_issue`, `regression`, `duplicate_candidate`, `blocked`, or `no_change`. Supply a stable concern key, issue matches and rejected matches, evidence, confidence rationale, proposed operation, and conditions preventing application. Confidence labels describe evidence quality, not calibrated probabilities.

## Apply supported changes

- **Complete:** transition to the team's discovered completed state, or GitHub closed/completed, only when all acceptance conditions are supported at current head, no later contradiction/revert exists, and required deployment/manual acceptance has been verified. Do not close a parent with unfinished acceptance or children. A partly implemented issue stays open with criterion coverage and remaining work.
- **Drift/add-on:** preserve the original requested behavior and decisions. Add a clearly bounded evidence section describing delivered changes, remaining scope and updated criteria. New product choices remain explicitly undecided; do not invent requirements from preference. Preserve assignee, priority, estimate, cycle, milestone, and due date unless change is evidence-backed and authorized.
- **Missing work:** first search titles, semantic synonyms, source PR links, concern markers, existing subissues, duplicate chains, and both trackers where a cross-link map exists. Update the canonical existing issue when it covers the concern. Otherwise create a concrete, actionable issue with observed/expected behavior, impact, evidence, acceptance checks, dependencies and unknowns. Use a new issue only for independently actionable scope; otherwise append to the existing issue. Do not generate speculative cleanup tickets for every PR or TODO.
- **Regression/revert:** inspect current code and the exact affected criteria. Reopen the original issue only when it represents the same still-required work and policy allows it; otherwise create/link a regression follow-up. A release rollback does not automatically reopen every issue in the release.
- **Duplicates:** cross-link and explain confidence; only mark duplicate when identity is established. Never delete or auto-merge issues. Use discovered team labels/statuses, not invented IDs or labels.

Apply sequentially per issue after rereading touched fields. Use exact managed-section patches/additive operations. Replan on a human edit. Journal intent, remote IDs, partial results and verification. Recover uncertain creates by searching markers and links before retrying. Re-read results; success means the intended fields and evidence are present. Update the completed checkpoint only for fully reviewed contiguous intervals with verified writes and durable state. A partial run retains completed per-item work and an explicit pending queue.

Finish with linked created/updated/completed/reopened items, uncertainty and retry queue, coverage interval and head SHAs, unavailable sources, and priority queue. Interactive callers then use grill-issue; unattended callers stop here. Optional offline helper: resolve this skill's directory, then run `python <skill-directory>/scripts/core.py --help`; its booleans must come from real source review, not assumptions. Ignore unchanged provenance-marked housekeeping when looking for new product work; retain human changes as evidence.
