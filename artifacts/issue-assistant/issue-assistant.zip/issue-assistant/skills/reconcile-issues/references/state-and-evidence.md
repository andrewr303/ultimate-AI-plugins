# Evidence, queue and durable state

## Stable identity and remote recovery

Concern identity is the normalized scope plus a durable semantic concern key, for example `api-retry/cancel-leaves-job-running`. It must not contain run timestamps, new evidence lists or mutable issue titles. Store it as a bounded marker in the managed issue section or comment: `<!-- issue-assistant:concern:<fingerprint> -->`. An operation key combines concern identity, operation kind and canonical desired fields. Evidence revision and run ID are separate fields. This makes new evidence update the same concern rather than create a new ticket.

Before create, re-search all relevant open/closed issues and comments for the concern key, PR link and synonyms. After a timeout, assume unknown outcome, not failure; recover by exact remote lookup. If identity cannot be recovered reliably, leave `uncertain` and skip the retry. Retain verified receipts across baseline repeats.

Each operation records run/scope ID, concern ID, operation key, target, desired fields, source IDs/revision, expected prior touched values, state (`planned`, `applied`, `verified`, `uncertain`, `failed`), returned remote ID, and read-back result. A close and its audit comment are separate operations: retry the missing comment without repeating the state change. Preserve prior field values for a reviewable corrective patch; undo must preserve subsequent human edits.

Only one run writes a given scope at a time. Hosted jobs should load a single scoped Linear ledger document (or GitHub ledger issue when GitHub-only), including a lease owner/expiry and version. Re-read and use an exact-match state replacement where supported, then verify lease ownership. Renew during long work. Skip a live lease. With non-atomic providers a lease is best-effort: recheck immediately before writes; if exclusivity cannot be established, collect findings and skip contested writes. Never claim distributed exactly-once execution or a cross-provider transaction.

## Hosted manifest

Use a scoped tracker document titled `Issue Assistant — reconciliation ledger` with a unique `scope_id` marker. Store no secrets or full transcripts. Discover it by scope before creating it. The manifest contains schema version, scope (repo allowlist and tracker IDs), per-source completed-through timestamps, pinned heads, coverage intervals/gaps, reviewed PR revisions, verified operation receipts, uncertain/pending operations, deferred decisions, active interview if applicable, lease and last result.

Keep one exact, uniquely delimited state section with a fenced JSON block. Fencing prevents rich-text Markdown normalization from escaping JSON array brackets. Parse and verify it after every write. For example:

````
<!-- issue-assistant:state:begin -->
```json
{"schema_version":1,"scope_id":"...","completed_through":null,"pending":[],"receipts":[]}
```
<!-- issue-assistant:state:end -->
````

Read full current content before patching only the state section; preserve explanatory text and human edits. On conflict reread and reconcile receipts by operation key; never overwrite with an empty ledger. If the manifest is unavailable, first recover remote concern markers and repeat the baseline. Do not issue creates or state transitions until duplicate/uncertain outcomes have been resolved. If state cannot be persisted, report the blocker and retain the checkpoint; never declare the run complete.

Persist intent before mutation and receipt after verification. A crash between them is recovered remotely. Advance only a fully covered contiguous source interval; a partial page or unverified required write leaves its interval pending. Older verified work remains verified. Record unexposed histories as unavailable rather than as empty. A temporary local helper journal is supplementary on hosted runs.

## Completion gate

Every criterion needs an actual source reference and current-state check. Tests support only the behavior they exercise. Require current implementation evidence plus meaningful validation; PR text, agent promises, and title similarity alone cannot pass. Resolve later changes, reverts and contradictory reports. Incomplete coverage of relevant code/checks/issue scope blocks automatic completion, even if global unrelated history is unavailable. If deployment or human acceptance is part of the issue, require its own evidence. Preserve explicit manual gates and keep parents open while required child outcomes remain incomplete.

## Queue ordering

Use refreshed native priority: urgent, high, medium, low, then unspecified. Explain an explicit deadline/incident override; never invent deadlines. Build dependency order inside each priority group: surface actionable blockers needed by a higher-priority issue and explain the promotion. A blocked high-priority issue is visible but not presented as ready to code. Dependency cycles become a context/decision question. Tie-break by verified due date, impact and oldest unresolved age; label inferred impact and unknown priority. Respect the user's defer/snooze decision until its date or material new evidence. Do not defer an urgent issue on a guessed date.

The interview queue can differ from stored priority without changing the tracker. Keep the active issue until resolved, skipped, delegated by explicit request, or deferred. Record resolved decisions so the next session does not re-ask them.
