---
name: break-down-issue
description: "Use when the user wants a Linear or GitHub issue split into smaller actionable subtasks with evidence, acceptance checks and explicit dependencies."
---

# Break down an issue

Read parent scope, existing children, current code, relevant PRs and recorded decisions. Identify the remaining outcome after completed work; do not create tasks to redo delivered code. Use independently verifiable vertical slices of behavior rather than one ticket per technical layer. Include a research spike only when a concrete uncertainty prevents a useful implementation slice; bound its output and stopping condition.

For each child specify: observed problem, expected outcome, in/out scope, source links, code entrypoints when verified, acceptance tests, dependencies, risks and unknowns. Preserve the parent's original acceptance conditions and map each remaining one to a child. Shared migration/schema work may be a prerequisite; identify one owner/writer for shared files where relevant. Never fabricate estimates, assignees or delivery dates.

Search existing issues and children before creating. Stable concern markers and read-back verification follow [state and evidence](../reconcile-issues/references/state-and-evidence.md). Reuse an existing child for the same outcome. Create prerequisites first, then dependent slices, then add native Linear `parentId` and blocker relationships. For GitHub use discovered native sub-issues/dependencies when available, otherwise upsert a linked child checklist and backlinks with an explicit fallback disclosure. Preserve human text and relationships.

When the user asks to split/create subtasks, perform the supported tracker writes without requiring a second approval. If they ask only for a plan, return the concrete plan without writes. If a material product choice prevents decomposition, ask one question in interactive mode; unattended mode records the unknown and creates only independently supported work.

Report child links and dependency order, map acceptance coverage, explain the first actionable slice, and keep the parent open until its own acceptance is complete. Return to the caller's interview or implementation workflow.
