# Validation

Validated on 2026-10-19 with Python 3.12.14.

- `python -m unittest discover -s tests -q`: 48 tests passed. These exercise the offline helper's window boundaries, explicit completion gates, evidence references, deployment/manual acceptance requirements, priority and dependency ordering, duplicate/conflicting findings, uncertain outcomes, journal corruption and CLI contracts.
- Parsed the portable manifest, both verified app bindings, all five skill frontmatters and optional agent metadata. Checked the short-description length, included icon, contained relative links, JSON/JSONL files and archive exclusions.
- Independent documentation review completed; fixes incorporated for hosted state recovery/leases, source trust, GitHub issue-body fallback, housekeeping loops, and helper path resolution.
- Live harmless reads succeeded for the connected GitHub profile, accessible repositories, HypeStake merged PR search, Linear workspace/team/projects and issue states. This establishes connection and scope access, not semantic correctness of a full audit.
- Created the HypeStake reconciliation ledger, read it back and parsed its fenced JSON state successfully. Checkpoints remain null until a complete run. Fenced JSON prevents Markdown normalization from escaping arrays.

The tests do not execute an LLM interview, prove that a supplied evidence claim is true, mutate live product issues, or certify a full backlog reconciliation. The host has no separate plugin validation command in the available CLI; account ingestion and component diagnostics are checked at save time. Hosted schedule activation is verified separately from the package. First scheduled reconciliation remains pending until its run completes.

Research was manually source-reviewed, with seven pinned finalists and explicit uncertainty annexes. No automated research validator was available; no automated research PASS or verified_claims.json is asserted. No upstream candidate code or skill prose was copied or executed.
